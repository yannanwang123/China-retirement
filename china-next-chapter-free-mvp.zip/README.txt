CHINA NEXT CHAPTER — FREE MVP

1. Open index.html in a browser to preview the site.
2. The "Apply" button currently opens Google Forms.
3. Create your own free Google Form and replace the forms.google.com URL in index.html with your form URL.
4. To publish free: use GitHub Pages, Netlify, or another static-site host.
5. No paid domain is required for the first market test.
